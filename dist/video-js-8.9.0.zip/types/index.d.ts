export default videojs;
import videojs from "./video";
//# sourceMappingURL=index.d.ts.map